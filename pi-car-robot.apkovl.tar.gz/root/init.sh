#!/bin/sh

export JAVA_HOME="/media/java/jvm/default-jvm" \
MAVEN_HOME="/media/maven/home" \
PATH="/media/maven/home/bin:$JAVA_HOME/bin:$PATH"

