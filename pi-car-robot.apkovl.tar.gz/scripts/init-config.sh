#!/bin/sh
lbu include /lib/firmware/brcm
lbu include /scripts
lbu include /root
lbu ci